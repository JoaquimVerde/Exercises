package mindera.bootcamp.exercises.ExceptionsExercise.exceptions;

public class ATMException extends Exception {

    public ATMException(String message) {
        super(message);


    }

}
