package mindera.bootcamp.exercises.ExceptionsExercise.exceptions;

public class NotEnoughFundsException extends ATMException {


    public NotEnoughFundsException() {
        super("Not enough funds.");
    }


}
