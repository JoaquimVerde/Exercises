package mindera.bootcamp.exercises.ExceptionsExercise;

public class Card {

    private int balance;

    private int pinNumber;


    public int getBalance() {
        return balance;
    }

    public int getPinNumber() {
        return pinNumber;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public void setPinNumber(int pinNumber) {
        this.pinNumber = pinNumber;
    }
}
